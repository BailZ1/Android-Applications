// Assignment 07
// BooksFragment.java
// Bailey Bowling

package edu.uncc.assignment07;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class BooksFragment extends Fragment {

    private static final String ARG_GENRE = "genre";
    private String genre;
    private List<Book> books;
    private BooksListener mListener;

    public interface BooksListener {
        void gotoBookDetails(Book book);
        void goBackToGenres();
    }

    public static BooksFragment newInstance(String genre) {
        BooksFragment fragment = new BooksFragment();
        Bundle args = new Bundle();
        args.putString(ARG_GENRE, genre);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BooksListener) {
            mListener = (BooksListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement BooksListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_books, container, false);

        if (getArguments() != null) {
            genre = getArguments().getString(ARG_GENRE);
        }

        TextView textViewGenre = view.findViewById(R.id.textViewGenre);
        textViewGenre.setText(genre);

        ListView listView = view.findViewById(R.id.listViewBooks);
        books = Data.getBooksByGenre(genre);

        BookAdapter adapter = new BookAdapter();
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Book book = books.get(position);
                mListener.gotoBookDetails(book);
            }
        });

        view.findViewById(R.id.buttonBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.goBackToGenres();
            }
        });

        return view;
    }

    private class BookAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return books.size();
        }

        @Override
        public Object getItem(int position) {
            return books.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_books, parent, false);
            }

            // Create a vertical LinearLayout to hold book details
            LinearLayout layout = new LinearLayout(getContext());
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(10, 10, 10, 10);

            TextView textViewTitle = new TextView(getContext());
            TextView textViewAuthor = new TextView(getContext());
            TextView textViewGenre = new TextView(getContext());
            TextView textViewYear = new TextView(getContext());

            Book book = books.get(position);

            textViewTitle.setText(book.getTitle());
            textViewTitle.setTextAppearance(android.R.style.TextAppearance_Large);
            textViewTitle.setTypeface(null, Typeface.BOLD);

            textViewAuthor.setText(book.getAuthor());
            textViewGenre.setText(book.getGenre());
            textViewYear.setText(String.valueOf(book.getYear()));

            layout.addView(textViewTitle);
            layout.addView(textViewAuthor);
            layout.addView(textViewGenre);
            layout.addView(textViewYear);

            return layout;
        }
    }
}
